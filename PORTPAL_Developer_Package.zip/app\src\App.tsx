import { HashRouter, Routes, Route } from 'react-router-dom'
import { PhoneFrame } from './components/PhoneFrame'
import { Navigation } from './components/Navigation'
import { Home } from './pages/Home'
import { Shifts } from './pages/Shifts'
import { Calendar } from './pages/Calendar'
import { Analytics } from './pages/Analytics'
import { Chat } from './pages/Chat'
import { Subscribe } from './pages/Subscribe'
import { Landing } from './pages/Landing'
import { Dashboard } from './pages/Dashboard'
import { CommandCenter } from './pages/CommandCenter'
import { SocialPreview } from './social/SocialPreview'
import { InstagramMockup } from './social/InstagramMockup'

function PhoneApp() {
  return (
    <div className="min-h-screen bg-slate-100 flex">
      {/* Design Notes Sidebar */}
      <div className="hidden lg:block w-80 p-6 bg-white border-r overflow-y-auto">
        <h2 className="text-xl font-bold text-slate-800 mb-4">PORTPAL Design Notes</h2>

        <div className="space-y-4 text-sm text-slate-600">
          <div className="p-3 bg-blue-50 rounded-lg">
            <h3 className="font-semibold text-blue-800">Color Palette</h3>
            <p className="mt-1">Navy/Blue = Maritime heritage. Orange = Safety gear worn on docks. Clean whites for readability.</p>
          </div>

          <div className="p-3 bg-orange-50 rounded-lg">
            <h3 className="font-semibold text-orange-800">Home Screen</h3>
            <p className="mt-1">Quick glance at this week's earnings. Pension progress bar shows year-to-date toward $120k goal. Streaks reward consistent logging.</p>
          </div>

          <div className="p-3 bg-green-50 rounded-lg">
            <h3 className="font-semibold text-green-800">Shift Entry</h3>
            <p className="mt-1">Pre-fills based on PAYDIFFS data. User picks Job → Location → Shift, we auto-calculate pay. Smart defaults from their history.</p>
          </div>

          <div className="p-3 bg-purple-50 rounded-lg">
            <h3 className="font-semibold text-purple-800">Calendar View</h3>
            <p className="mt-1">Week view matches 2-week pay period. Color-coded by shift type. Tap to edit. Pull reports by date range.</p>
          </div>

          <div className="p-3 bg-slate-50 rounded-lg">
            <h3 className="font-semibold text-slate-800">Analytics</h3>
            <p className="mt-1">Where you've worked (terminal breakdown), earnings by month, hours by shift type. Identify patterns.</p>
          </div>

          <div className="p-3 bg-cyan-50 rounded-lg">
            <h3 className="font-semibold text-cyan-800">AI Chat</h3>
            <p className="mt-1">Ask questions about collective agreement, rates, blackbook rules. Upload pay stubs to detect discrepancies.</p>
          </div>

          <div className="mt-6 p-3 border-2 border-dashed border-slate-300 rounded-lg">
            <h3 className="font-semibold text-slate-700">Data Sources</h3>
            <ul className="mt-2 space-y-1 text-xs">
              <li>• 71,712 user shift records</li>
              <li>• 990 job/location/shift combos</li>
              <li>• BCMEA rates Years 1-4</li>
              <li>• 42 job types, 24 locations</li>
            </ul>
          </div>
        </div>
      </div>

      {/* Phone Preview */}
      <div className="flex-1 flex items-center justify-center p-8">
        <PhoneFrame>
          <div className="h-full flex flex-col bg-slate-50">
            <div className="flex-1 overflow-y-auto no-scrollbar">
              <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/shifts" element={<Shifts />} />
                <Route path="/calendar" element={<Calendar />} />
                <Route path="/analytics" element={<Analytics />} />
                <Route path="/chat" element={<Chat />} />
                <Route path="/subscribe" element={<Subscribe />} />
              </Routes>
            </div>
            <Navigation />
          </div>
        </PhoneFrame>
      </div>

      {/* Feature Notes Sidebar */}
      <div className="hidden xl:block w-80 p-6 bg-white border-l overflow-y-auto">
        <h2 className="text-xl font-bold text-slate-800 mb-4">Future Features</h2>

        <div className="space-y-4 text-sm text-slate-600">
          <div className="p-3 bg-amber-50 rounded-lg border-l-4 border-amber-400">
            <h3 className="font-semibold text-amber-800">Pay Stub Upload</h3>
            <p className="mt-1">OCR extracts earnings. Compare vs logged shifts. Flag discrepancies. Learn correct rates from real data.</p>
          </div>

          <div className="p-3 bg-red-50 rounded-lg border-l-4 border-red-400">
            <h3 className="font-semibold text-red-800">Shortage Tracking</h3>
            <p className="mt-1">Record when underpaid. Track resolution status. Get notified when differential arrives.</p>
          </div>

          <div className="p-3 bg-indigo-50 rounded-lg border-l-4 border-indigo-400">
            <h3 className="font-semibold text-indigo-800">Job Prediction</h3>
            <p className="mt-1">Based on seniority, board position, historical dispatch data. "70% chance of Ship Gantry tomorrow"</p>
          </div>

          <div className="p-3 bg-teal-50 rounded-lg border-l-4 border-teal-400">
            <h3 className="font-semibold text-teal-800">News Feed</h3>
            <p className="mt-1">Maritime industry news. Shipping company updates. Contract negotiations. Union announcements.</p>
          </div>

          <div className="p-3 bg-pink-50 rounded-lg border-l-4 border-pink-400">
            <h3 className="font-semibold text-pink-800">Sick Day Tracking</h3>
            <p className="mt-1">Log sick days. Track qualifying days for benefits. Vacation accrual at 4%.</p>
          </div>

          <div className="mt-6 p-4 bg-gradient-to-br from-blue-600 to-blue-800 rounded-lg text-white">
            <h3 className="font-bold">Why This Matters</h3>
            <p className="mt-2 text-blue-100 text-xs">
              Longshoremen work 7 different jobs with 7 different rates in a week.
              Without tracking, pay errors go unnoticed.
              This app empowers workers to audit their own pay and strengthens the union through organized data.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}

function App() {
  return (
    <HashRouter>
      <Routes>
        <Route path="/landing" element={<Landing />} />
        <Route path="/signup" element={<Landing />} />
        <Route path="/social" element={<SocialPreview />} />
        <Route path="/instagram" element={<InstagramMockup />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/command-center" element={<CommandCenter />} />
        <Route path="/*" element={<PhoneApp />} />
      </Routes>
    </HashRouter>
  )
}

export default App
